import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { PhoneFrame, TopBar, PrimaryButton, Badge } from "@/components/famio/ui";
import { getProvider, reviewsByProvider, defaultReviews } from "@/lib/mock/data";
import { useApp } from "@/lib/store";
import { Heart, Share2, Star, ShieldCheck, MapPin, Languages, Briefcase, Calendar } from "lucide-react";

export const Route = createFileRoute("/provider/$id")({
  component: ProviderProfile,
  loader: ({ params }) => {
    const p = getProvider(params.id);
    if (!p) throw notFound();
    return { p };
  },
  notFoundComponent: () => <div className="p-8 text-center">Provider not found</div>,
  errorComponent: ({ error }) => <div className="p-8 text-center">{String(error)}</div>,
});

function ProviderProfile() {
  const { p } = Route.useLoaderData();
  const { favorites, toggleFavorite } = useApp();
  const nav = useNavigate();
  const isFav = favorites.includes(p.id);
  const reviews = reviewsByProvider[p.id] || defaultReviews;

  return (
    <PhoneFrame>
      <div className="relative">
        <div className="h-72 w-full overflow-hidden">
          <img src={p.avatar} alt={p.name} className="h-full w-full object-cover" />
          <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/60 via-transparent" />
        </div>
        <TopBar
          back={{ to: "/home" }}
          transparent
          right={
            <div className="flex gap-2">
              <button className="grid h-10 w-10 place-items-center rounded-full bg-white/90 shadow-soft">
                <Share2 className="h-4 w-4" />
              </button>
              <button
                onClick={() => toggleFavorite(p.id)}
                className="grid h-10 w-10 place-items-center rounded-full bg-white/90 shadow-soft"
              >
                <Heart className={`h-4 w-4 ${isFav ? "fill-coral text-coral" : ""}`} />
              </button>
            </div>
          }
        />
        <div className="pointer-events-none absolute inset-x-5 bottom-4 text-white">
          <div className="flex items-center gap-2">
            <Badge tone={p.role === "Angel" ? "coral" : "navy"}>{p.role}</Badge>
            <Badge tone="mint"><ShieldCheck className="h-3 w-3" /> Trust {p.trustScore}</Badge>
          </div>
          <h1 className="mt-2 text-3xl font-extrabold">{p.name}</h1>
          <div className="flex items-center gap-3 text-sm">
            <span className="inline-flex items-center gap-1"><Star className="h-3.5 w-3.5 fill-warning text-warning" /> {p.rating} ({p.reviews})</span>
            <span>·</span>
            <span>EGP {p.hourlyRate}/hr</span>
          </div>
        </div>
      </div>

      <div className="-mt-5 flex-1 rounded-t-3xl bg-surface-2 px-5 pt-5 pb-28">
        <div className="grid grid-cols-3 gap-2">
          <Stat icon={<Briefcase className="h-4 w-4" />} label="Jobs" value={p.jobs.toString()} />
          <Stat icon={<Calendar className="h-4 w-4" />} label="Years" value={p.yearsExp.toString()} />
          <Stat icon={<Star className="h-4 w-4" />} label="Rating" value={p.rating.toFixed(1)} />
        </div>

        <Section title="About">
          <p className="text-sm leading-relaxed text-foreground">{p.bio}</p>
        </Section>

        <Section title="Verified by Famio">
          <div className="flex flex-wrap gap-2">
            {p.badges.map((b: string) => (
              <span key={b} className="inline-flex items-center gap-1 rounded-full bg-surface px-3 py-1.5 text-xs font-semibold shadow-soft">
                <ShieldCheck className="h-3 w-3 text-success" /> {b}
              </span>
            ))}
          </div>
        </Section>

        <Section title="Languages">
          <div className="flex items-center gap-2 text-sm">
            <Languages className="h-4 w-4 text-muted-foreground" />
            {p.languages.join(" · ")}
          </div>
        </Section>

        <Section title="Service areas">
          <div className="flex items-center gap-2 text-sm">
            <MapPin className="h-4 w-4 text-coral" />
            {p.areas.join(" · ")}
          </div>
        </Section>

        <Section title="Gallery">
          <div className="-mx-5 overflow-x-auto no-scrollbar">
            <div className="flex gap-3 px-5">
              {p.gallery.map((g: string) => (
                <img key={g} src={g} alt="" className="h-28 w-40 shrink-0 rounded-2xl object-cover" />
              ))}
            </div>
          </div>
        </Section>

        <Section title="Availability this week">
          <div className="grid grid-cols-7 gap-1.5">
            {["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map((d, i) => {
              const busy = i === 2 || i === 5;
              return (
                <div key={d} className={`rounded-2xl p-2 text-center ${busy ? "bg-muted text-muted-foreground" : "bg-mint/30 text-foreground"}`}>
                  <div className="text-[10px] font-bold uppercase">{d}</div>
                  <div className="mt-1 text-[10px]">{busy ? "Busy" : "Free"}</div>
                </div>
              );
            })}
          </div>
        </Section>

        <Section title={`Reviews (${p.reviews})`}>
          <div className="space-y-3">
            {reviews.map((r) => (
              <div key={r.id} className="rounded-2xl bg-surface p-4 shadow-soft">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-bold">{r.name}</div>
                  <div className="text-[11px] text-muted-foreground">{r.date}</div>
                </div>
                <div className="mt-1 flex">
                  {Array.from({ length: 5 }).map((_, i) => (
                    <Star key={i} className={`h-3.5 w-3.5 ${i < r.rating ? "fill-warning text-warning" : "text-muted"}`} />
                  ))}
                </div>
                <p className="mt-2 text-sm text-foreground/90">{r.text}</p>
              </div>
            ))}
          </div>
        </Section>
      </div>

      <div className="safe-bottom fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md border-t border-border bg-surface px-5 pt-3">
        <PrimaryButton variant="coral" onClick={() => nav({ to: "/book/$providerId", params: { providerId: p.id } })}>
          Book Now · EGP {p.hourlyRate}/hr
        </PrimaryButton>
      </div>
    </PhoneFrame>
  );
}

function Stat({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-2xl bg-surface p-3 text-center shadow-soft">
      <div className="mx-auto grid h-8 w-8 place-items-center rounded-xl bg-navy/10 text-navy">{icon}</div>
      <div className="mt-1.5 text-base font-extrabold">{value}</div>
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6">
      <h2 className="mb-2 text-sm font-extrabold uppercase tracking-wide text-muted-foreground">{title}</h2>
      {children}
    </div>
  );
}
