import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { AppShell, TopBar, Card } from "@/components/famio/ui";
import { useApp } from "@/lib/store";
import { MapPin, CreditCard, Users, Bell, Globe, HelpCircle, FileText, Shield, LogOut, ChevronRight, Heart } from "lucide-react";

export const Route = createFileRoute("/profile")({ component: Profile });

function Profile() {
  const { profile, reset } = useApp();
  const nav = useNavigate();

  return (
    <AppShell>
      <TopBar title="Profile" />
      <div className="px-5">
        <Card className="p-5">
          <div className="flex items-center gap-4">
            <div className="grid h-16 w-16 shrink-0 place-items-center rounded-2xl bg-navy text-2xl font-extrabold text-navy-foreground">
              {profile.name ? profile.name.charAt(0).toUpperCase() : "F"}
            </div>
            <div className="min-w-0">
              <div className="truncate text-lg font-extrabold">{profile.name || "Famio user"}</div>
              <div className="truncate text-xs text-muted-foreground">{profile.phone || "—"}</div>
              <Link to="/setup" className="mt-1.5 inline-block text-xs font-bold text-navy">Edit profile</Link>
            </div>
          </div>
        </Card>

        <Section title="My Famio">
          <Row to="/favorites" icon={<Heart className="h-5 w-5" />} label="Favorites" />
          <Row to="/setup" icon={<MapPin className="h-5 w-5" />} label="Addresses" sub={profile.compound || "Add address"} />
          <Row icon={<CreditCard className="h-5 w-5" />} label="Payment methods" sub="Cards & wallets" />
          <Row icon={<Users className="h-5 w-5" />} label="Family members" sub="Add kids & guardians" />
        </Section>

        <Section title="Preferences">
          <Row icon={<Bell className="h-5 w-5" />} label="Notifications" />
          <Row icon={<Globe className="h-5 w-5" />} label="Language" sub="English" />
        </Section>

        <Section title="Support & legal">
          <Row to="/help" icon={<HelpCircle className="h-5 w-5" />} label="Help center" />
          <Row icon={<FileText className="h-5 w-5" />} label="Terms of service" />
          <Row icon={<Shield className="h-5 w-5" />} label="Privacy policy" />
        </Section>

        <div className="mt-6 space-y-2">
          <button
            onClick={() => { reset(); nav({ to: "/" }); }}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-surface py-4 text-sm font-bold text-destructive shadow-soft"
          >
            <LogOut className="h-4 w-4" /> Log out
          </button>
          <button className="w-full py-3 text-xs font-semibold text-muted-foreground">Delete account</button>
        </div>

        <div className="pt-6 pb-2 text-center text-[11px] text-muted-foreground">Famio · v1.0.0</div>
      </div>
    </AppShell>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="mt-6">
      <h2 className="mb-2 px-1 text-[11px] font-extrabold uppercase tracking-wider text-muted-foreground">{title}</h2>
      <div className="divide-y divide-border rounded-3xl bg-surface shadow-soft">{children}</div>
    </div>
  );
}

function Row({ icon, label, sub, to }: { icon: React.ReactNode; label: string; sub?: string; to?: string }) {
  const inner = (
    <div className="flex items-center gap-3 px-4 py-3.5 active:bg-surface-2">
      <div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-navy/10 text-navy">{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="truncate text-sm font-bold">{label}</div>
        {sub && <div className="truncate text-[11px] text-muted-foreground">{sub}</div>}
      </div>
      <ChevronRight className="h-4 w-4 text-muted-foreground" />
    </div>
  );
  if (to) return <Link to={to as any}>{inner}</Link>;
  return <button className="w-full text-left">{inner}</button>;
}
