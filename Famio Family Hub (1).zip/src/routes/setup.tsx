import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { PhoneFrame, PrimaryButton, TopBar } from "@/components/famio/ui";
import { useApp } from "@/lib/store";
import { Camera, MapPin } from "lucide-react";

export const Route = createFileRoute("/setup")({ component: Setup });

function Setup() {
  const { profile, setProfile } = useApp();
  const nav = useNavigate();
  const [form, setForm] = useState(profile);

  const update = (k: keyof typeof form, v: string) => setForm({ ...form, [k]: v });
  const valid = form.name.trim().length > 1 && form.address.trim().length > 2;

  const submit = () => {
    if (!valid) return;
    setProfile(form);
    nav({ to: "/home" });
  };

  return (
    <PhoneFrame bg="bg-surface">
      <TopBar title="Complete your profile" />
      <div className="flex-1 space-y-5 px-6 pb-6 pt-2">
        <div className="flex flex-col items-center pb-2">
          <div className="relative">
            <div className="grid h-24 w-24 place-items-center rounded-full bg-navy/10 text-3xl font-extrabold text-navy">
              {form.name ? form.name.charAt(0).toUpperCase() : "F"}
            </div>
            <button className="absolute -bottom-1 -right-1 grid h-9 w-9 place-items-center rounded-full bg-coral text-coral-foreground shadow-card">
              <Camera className="h-4 w-4" />
            </button>
          </div>
          <p className="mt-3 text-xs text-muted-foreground">Add a profile photo (optional)</p>
        </div>

        <Field label="Your name" value={form.name} onChange={(v) => update("name", v)} placeholder="Sarah Mostafa" />
        <Field label="Compound / Area" value={form.compound} onChange={(v) => update("compound", v)} placeholder="Allegria, Sheikh Zayed" />
        <Field label="Building / Villa" value={form.building} onChange={(v) => update("building", v)} placeholder="Villa 12" />
        <Field label="Apartment" value={form.apartment} onChange={(v) => update("apartment", v)} placeholder="Apt 3B (optional)" />

        <div>
          <label className="block text-xs font-bold uppercase tracking-wide text-muted-foreground">Address</label>
          <div className="mt-2 flex items-start gap-3 rounded-2xl border border-border bg-surface px-4 py-3">
            <MapPin className="mt-0.5 h-5 w-5 shrink-0 text-coral" />
            <textarea
              rows={2}
              placeholder="Street, landmark, gate number..."
              value={form.address}
              onChange={(e) => update("address", e.target.value)}
              className="min-w-0 flex-1 resize-none bg-transparent text-[15px] font-medium outline-none placeholder:text-muted-foreground/60"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold uppercase tracking-wide text-muted-foreground">Additional notes</label>
          <textarea
            rows={2}
            placeholder="Anything we should know? (Gate code, dogs, etc.)"
            value={form.notes}
            onChange={(e) => update("notes", e.target.value)}
            className="mt-2 w-full resize-none rounded-2xl border border-border bg-surface px-4 py-3 text-[15px] outline-none focus:border-navy"
          />
        </div>
      </div>
      <div className="safe-bottom border-t border-border bg-surface px-6 pt-4">
        <PrimaryButton onClick={submit} disabled={!valid}>Continue</PrimaryButton>
      </div>
    </PhoneFrame>
  );
}

function Field({ label, value, onChange, placeholder }: { label: string; value: string; onChange: (v: string) => void; placeholder: string }) {
  return (
    <div>
      <label className="block text-xs font-bold uppercase tracking-wide text-muted-foreground">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        className="mt-2 h-14 w-full rounded-2xl border border-border bg-surface px-4 text-[15px] font-medium outline-none focus:border-navy"
      />
    </div>
  );
}
