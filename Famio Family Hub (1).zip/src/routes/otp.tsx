import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { PhoneFrame, PrimaryButton, TopBar } from "@/components/famio/ui";
import { useApp } from "@/lib/store";

export const Route = createFileRoute("/otp")({ component: Otp });

function Otp() {
  const [code, setCode] = useState(["", "", "", ""]);
  const refs = useRef<(HTMLInputElement | null)[]>([]);
  const [timer, setTimer] = useState(30);
  const [loading, setLoading] = useState(false);
  const nav = useNavigate();
  const { setAuthed, profile } = useApp();

  useEffect(() => {
    refs.current[0]?.focus();
    const t = setInterval(() => setTimer((x) => (x > 0 ? x - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, []);

  const onChange = (i: number, v: string) => {
    const d = v.replace(/\D/g, "").slice(-1);
    const next = [...code];
    next[i] = d;
    setCode(next);
    if (d && i < 3) refs.current[i + 1]?.focus();
    if (next.every((c) => c) && !loading) verify(next.join(""));
  };

  const verify = (val: string) => {
    if (val.length !== 4) return;
    setLoading(true);
    setTimeout(() => {
      setAuthed(true);
      nav({ to: profile.name ? "/home" : "/setup" });
    }, 900);
  };

  return (
    <PhoneFrame bg="bg-surface">
      <TopBar back={{ to: "/login" }} />
      <div className="flex-1 px-6 pt-2">
        <h1 className="text-3xl font-extrabold tracking-tight">Verify your number</h1>
        <p className="mt-2 text-[15px] text-muted-foreground">
          We sent a 4-digit code to <span className="font-semibold text-foreground">{profile.phone || "+20 1XX XXX XXXX"}</span>
        </p>

        <div className="mt-10 flex justify-between gap-3">
          {code.map((c, i) => (
            <input
              key={i}
              ref={(el) => { refs.current[i] = el; }}
              inputMode="numeric"
              value={c}
              onChange={(e) => onChange(i, e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Backspace" && !c && i > 0) refs.current[i - 1]?.focus();
              }}
              className={`h-16 w-16 rounded-2xl border-2 bg-surface text-center text-2xl font-extrabold outline-none transition-all ${
                c ? "border-navy text-navy" : "border-border"
              }`}
            />
          ))}
        </div>

        <div className="mt-8 text-center text-sm text-muted-foreground">
          {timer > 0 ? (
            <>Resend code in <span className="font-bold text-foreground">{timer}s</span></>
          ) : (
            <button onClick={() => setTimer(30)} className="font-semibold text-navy">Resend code</button>
          )}
        </div>

        <p className="mt-6 text-center text-xs text-muted-foreground">Tip: any 4 digits work in this demo</p>
      </div>
      <div className="safe-bottom px-6 pt-4">
        <PrimaryButton onClick={() => verify(code.join(""))} disabled={loading || code.some((c) => !c)}>
          {loading ? "Verifying..." : "Verify"}
        </PrimaryButton>
      </div>
    </PhoneFrame>
  );
}
