import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { PhoneFrame, TopBar, Chip } from "@/components/famio/ui";
import { ProviderCard } from "@/components/famio/ProviderCard";
import { providers } from "@/lib/mock/data";
import { Search as SearchIcon, X } from "lucide-react";

export const Route = createFileRoute("/search")({ component: SearchPage });

function SearchPage() {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<"all" | "home" | "kids" | "top" | "near">("all");

  const results = useMemo(() => {
    const term = q.trim().toLowerCase();
    return providers.filter((p) => {
      if (filter === "home" && p.category !== "home") return false;
      if (filter === "kids" && p.category !== "kids") return false;
      if (filter === "top" && p.rating < 4.85) return false;
      if (!term) return true;
      return (
        p.name.toLowerCase().includes(term) ||
        p.bio.toLowerCase().includes(term) ||
        p.areas.some((a) => a.toLowerCase().includes(term))
      );
    });
  }, [q, filter]);

  return (
    <PhoneFrame>
      <TopBar back={{ to: "/home" }} title="Search" />
      <div className="px-5">
        <div className="flex h-14 items-center gap-3 rounded-2xl bg-surface px-4 shadow-soft">
          <SearchIcon className="h-5 w-5 text-muted-foreground" />
          <input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search professionals, services, areas"
            className="min-w-0 flex-1 bg-transparent text-[15px] outline-none"
          />
          {q && (
            <button onClick={() => setQ("")} className="grid h-7 w-7 place-items-center rounded-full bg-muted">
              <X className="h-3.5 w-3.5" />
            </button>
          )}
        </div>

        <div className="mt-4 flex gap-2 overflow-x-auto no-scrollbar">
          <Chip active={filter === "all"} onClick={() => setFilter("all")}>All</Chip>
          <Chip active={filter === "home"} onClick={() => setFilter("home")}>Famio Home</Chip>
          <Chip active={filter === "kids"} onClick={() => setFilter("kids")}>Famio Kids</Chip>
          <Chip active={filter === "top"} onClick={() => setFilter("top")}>Top rated</Chip>
          <Chip active={filter === "near"} onClick={() => setFilter("near")}>Near me</Chip>
        </div>

        <div className="mt-5 space-y-3 pb-10">
          {results.length === 0 ? (
            <div className="py-20 text-center">
              <div className="mx-auto grid h-20 w-20 place-items-center rounded-3xl bg-surface text-3xl shadow-soft">🔍</div>
              <div className="mt-4 text-base font-bold">No matches</div>
              <div className="text-xs text-muted-foreground">Try a different keyword or filter.</div>
            </div>
          ) : (
            results.map((p) => <ProviderCard key={p.id} p={p} />)
          )}
        </div>
      </div>
    </PhoneFrame>
  );
}
