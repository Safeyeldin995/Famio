import { createFileRoute, Link } from "@tanstack/react-router";
import { AppShell, TopBar } from "@/components/famio/ui";
import { mockMessages, getProvider } from "@/lib/mock/data";

export const Route = createFileRoute("/messages")({ component: Messages });

function Messages() {
  return (
    <AppShell>
      <TopBar title="Messages" />
      <div className="px-5">
        {mockMessages.length === 0 ? (
          <div className="py-20 text-center">
            <div className="mx-auto grid h-24 w-24 place-items-center rounded-3xl bg-surface text-4xl shadow-soft">💬</div>
            <div className="mt-5 text-base font-bold">No messages yet</div>
          </div>
        ) : (
          <ul className="divide-y divide-border rounded-3xl bg-surface shadow-soft">
            {mockMessages.map((m) => {
              const p = getProvider(m.providerId)!;
              return (
                <li key={m.id}>
                  <Link to="/messages/$id" params={{ id: m.id }} className="flex items-center gap-3 px-4 py-3 active:bg-surface-2">
                    <div className="relative shrink-0">
                      <img src={p.avatar} className="h-12 w-12 rounded-2xl object-cover" />
                      <span className="absolute -bottom-0.5 -right-0.5 h-3 w-3 rounded-full border-2 border-surface bg-success" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between">
                        <span className="truncate text-sm font-bold">{p.name}</span>
                        <span className="shrink-0 text-[11px] text-muted-foreground">{m.time}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="truncate text-xs text-muted-foreground">{m.lastMessage}</span>
                        {m.unread > 0 && (
                          <span className="grid h-5 min-w-5 place-items-center rounded-full bg-coral px-1.5 text-[10px] font-bold text-coral-foreground">{m.unread}</span>
                        )}
                      </div>
                    </div>
                  </Link>
                </li>
              );
            })}
          </ul>
        )}
      </div>
    </AppShell>
  );
}
